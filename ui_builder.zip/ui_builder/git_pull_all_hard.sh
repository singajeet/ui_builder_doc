git fetch --all
git reset --hard FETCH_HEAD
git clean -df
